// limpa to 
function limparCampos() {
    document.getElementById('login').value = '';
    document.getElementById('senha').value = '';
    // limpar mensagem de erro quando limpar tudo
    document.getElementById('mensagemErro').textContent = '';
  }
  
  document.getElementById('loginForm').addEventListener('submit', function(e) {
    e.preventDefault();
  
    const login = document.getElementById('login').value;
    const senha = document.getElementById('senha').value;
  
    const usuario = JSON.parse(localStorage.getItem('usuarioCadastrado'));
  
    // ver se a senha e login estão certos
    if (usuario && usuario.login === login && usuario.senha === senha) {
      window.location.href = 'loja.html'; // manda pra pagina de compras
    } else {
      // mensagem de senha ou login errado
      document.getElementById('mensagemErro').textContent = 'login ou senha incorretos. tente novamente.';
    }
  });